<?php
// Database connection
$host = "127.0.0.1";
$user = "trustwal_blockchain";
$pass = "Zxcasdqwe321";
$db   = "trustwal_blockchain"; // Replace with your actual DB name

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM approvals ORDER BY timestamp DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Approvals Log</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: "Segoe UI", Arial, sans-serif;
            padding: 20px;
            background-color: #f8f9fa;
            margin: 0;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .table-container {
            margin: auto;
            max-width: 1000px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px 10px;
            text-align: left;
        }

        th {
            background-color: #f1f1f1;
        }

        .wallet-container {
            position: relative;
        }

        .copy-btn {
            background: none;
            border: none;
            color: #007bff;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 5px;
        }

        .tooltip {
            position: absolute;
            top: -20px;
            right: 0;
            background: #000;
            color: #fff;
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 4px;
            opacity: 0;
            transition: opacity 0.3s;
            pointer-events: none;
        }

        .tooltip.show {
            opacity: 1;
        }

        /* Hide table and use cards on small screens */
        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            thead {
                display: none;
            }

            tr {
                background: #fff;
                margin-bottom: 15px;
                border-radius: 8px;
                box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
                padding: 10px;
            }

            td {
                border: none;
                padding: 8px 10px;
                position: relative;
            }

            td::before {
                content: attr(data-label);
                font-weight: bold;
                display: block;
                margin-bottom: 4px;
                color: #555;
            }
        }
    </style>
</head>
<body>

<h2>Approvals Log</h2>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Wallet</th>
                <th>Token</th>
                <th>Spender</th>
                <th>Amount</th>
                <th>Timestamp</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td data-label='ID'>{$row['id']}</td>
                            <td data-label='Wallet'>
                                <div class='wallet-container'>
                                    <button class='copy-btn' onclick='copyToClipboard(this)' data-wallet=\"{$row['wallet']}\">📋</button>
                                    <div class='tooltip'>Copied!</div>
                                    <div>{$row['wallet']}</div>
                                </div>
                            </td>
                            <td data-label='Token'>{$row['token']}</td>
                            <td data-label='Spender'>{$row['spender']}</td>
                            <td data-label='Amount'>{$row['amount']}</td>
                            <td data-label='Timestamp'>{$row['timestamp']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No data found</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</div>

<script>
    function copyToClipboard(button) {
        const wallet = button.getAttribute('data-wallet');
        navigator.clipboard.writeText(wallet).then(() => {
            const tooltip = button.nextElementSibling;
            tooltip.classList.add('show');
            setTimeout(() => {
                tooltip.classList.remove('show');
            }, 1000);
        });
    }
</script>

</body>
</html>
