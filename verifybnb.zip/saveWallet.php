<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input['wallet'])) {
        $wallet = $input['wallet'];
        file_put_contents('wallets.txt', $wallet . PHP_EOL, FILE_APPEND);
        echo json_encode(["message" => "Wallet saved"]);
    } else {
        http_response_code(400);
        echo json_encode(["error" => "No wallet address provided"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}
?>