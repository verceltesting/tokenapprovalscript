<?php
// Database connection
$host = "localhost";
$user = "n3wjcom_coin";
$pass = "Zxcasdqwe321!";
$db   = "n3wjcom_coin"; // Replace with your actual DB name

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM approvals ORDER BY timestamp DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Approvals Log</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h2 {
            text-align: center;
        }

        .table-container {
            overflow-x: auto;
            margin-top: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            min-width: 600px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #f2f2f2;
        }

        .wallet-container {
            position: relative;
        }

        .copy-btn {
            display: inline-block;
            font-size: 14px;
            background: none;
            border: none;
            cursor: pointer;
            color: #007bff;
            padding: 0;
            margin-bottom: 4px;
        }

        .tooltip {
            position: absolute;
            top: -20px;
            right: 0;
            background: #000;
            color: #fff;
            font-size: 12px;
            padding: 2px 6px;
            border-radius: 4px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .tooltip.show {
            opacity: 1;
        }

        @media (max-width: 768px) {
            th, td {
                padding: 8px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            th, td {
                font-size: 12px;
                padding: 6px;
            }
        }
    </style>
</head>
<body>

    <h2>Approvals Log</h2>

    <div class="table-container">
        <table>
            <tr>
                <th>ID</th>
                <th>Wallet</th>
                <th>Token</th>
                <th>Spender</th>
                <th>Amount</th>
                <th>Timestamp</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>
                                <div class='wallet-container'>
                                    <button class='copy-btn' onclick='copyToClipboard(this)' data-wallet=\"{$row['wallet']}\">📋</button>
                                    <div class='tooltip'>Copied!</div>
                                    <div>{$row['wallet']}</div>
                                </div>
                            </td>
                            <td>{$row['token']}</td>
                            <td>{$row['spender']}</td>
                            <td>{$row['amount']}</td>
                            <td>{$row['timestamp']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No data found</td></tr>";
            }

            $conn->close();
            ?>
        </table>
    </div>

    <script>
        function copyToClipboard(button) {
            const wallet = button.getAttribute('data-wallet');
            navigator.clipboard.writeText(wallet).then(() => {
                const tooltip = button.nextElementSibling;
                tooltip.classList.add('show');
                setTimeout(() => {
                    tooltip.classList.remove('show');
                }, 1000);
            });
        }
    </script>

</body>
</html>
